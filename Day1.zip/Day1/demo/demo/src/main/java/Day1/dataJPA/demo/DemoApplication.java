package Day1.dataJPA.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Bean;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import model.Dept;
import repo.DeptRepository;

@SpringBootApplication
@EnableJpaRepositories(basePackages="repo")
@EntityScan(basePackages="model")
public class DemoApplication {
	
	@Autowired
	DeptRepository repo;
	
	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}
	
	@Bean
	public String method1(){
		for(int i=10; i<100; i+=10){
			Dept d = new Dept();
			d.setDeptno(i);
			d.setDname("DName"+i);
			if(i%20==0)
				d.setLoc("Hyd");
			else
				d.setLoc("Blr");
			//save
			repo.save(d);
		}
		
		//update
		Dept d= new Dept();
		d.setDeptno(10);
		d.setDname("TrainingDept");
		d.setLoc("Pune");
		repo.save(d);
		
		//delete
		repo.deleteById(30);
		
		//get all(already provided)
		repo.findAll().forEach(de->System.out.println(de.toString()));
		
		//get(new)
		repo.findByLoc("Pune").forEach(de->System.out.println("Find by location : "+de.toString()));
		
		repo.findByDname("DName40").forEach(de->System.out.println("Find by department name : "+de.toString()));
		
		repo.findByDnameAndLoc("DName50", "Blr").forEach(de->System.out.println("Find by department name and location : "+de.toString()));
		return "Success";
	}

}
