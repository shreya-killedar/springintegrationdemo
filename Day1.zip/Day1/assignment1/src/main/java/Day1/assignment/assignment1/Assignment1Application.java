package Day1.assignment.assignment1;

import java.util.Date;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Bean;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import model.Employee;
import repo.EmployeeRepository;

@SpringBootApplication
@EnableJpaRepositories(basePackages="repo")
@EntityScan(basePackages="model")
public class Assignment1Application {

	@Autowired
	EmployeeRepository empRepo;
	
	public static void main(String[] args) {
		SpringApplication.run(Assignment1Application.class, args);
	}

	@Bean
	public String insert(){
		String[] names = new String[]{"Simran","Saloni","Alone","Ashwini","Amar"};
		String[] projects = new String[]{"Project1","Project2","Project3"};
		for(int i=1; i<50; i++){
			Employee e=new Employee();
			e.setName(names[i%names.length]);
			e.setSalary((int)(Math.random()*100)*10);
			e.setCom(i*10);
			e.setProject(projects[i%projects.length]);
			e.setBirthDate(new Date());
		
			empRepo.save(e);
		}		
		return "Success";
	}
	
	//@Bean
	public String sort(){
		//Ascending by project
		empRepo.findAll(Sort.by("project")).forEach(System.out::println);
		
		Sort s1 = new Sort(Direction.DESC,"name");
		Sort s2 = Sort.by("salary");
		
		//Descending by name
		empRepo.findAll(s1).forEach(System.out::println);
		
		//Ascending by salary and descending by name
		empRepo.findAll(s1.and(s2)).forEach(System.out::println);
		return "Success";
	}
	
	//@Bean
	public String page(){
		/*int pageNum = 0;
				
		Page<Employee> page = empRepo.findAll(PageRequest.of(pageNum, 10));
		System.out.println("Page no"+page.getNumber());
		page.get().forEach(System.out::println);
		while(page.hasNext()){
			Scanner sc = new Scanner(System.in);
			System.out.println("Do you want to continue? (N/P/Q)");
			String result = sc.nextLine();
			
			if(result.equalsIgnoreCase("N")){
				pageNum++;
				page = empRepo.findAll(PageRequest.of(pageNum, 10));
			} else if(result.equalsIgnoreCase("P") && pageNum > 0){
				pageNum--;
				page = empRepo.findAll(PageRequest.of(pageNum, 10));
			} else if(result.equalsIgnoreCase("Q")) {
				break;
			}
			
			page.get().forEach(System.out::println);
			
		}*/
		Pageable pageable=PageRequest.of(0,10);
		Scanner sc = new Scanner(System.in);
		char r = 'a';
		while(r !='Q'){
			Page<Employee> page = empRepo.findAll(pageable);
			page.get().forEach(System.out::println);
			System.out.println("Do you want to continue? (N/P/Q)");
			r=sc.next().charAt(0);
			if(r=='N'){
				pageable = pageable.next();
			} else if(r=='P'){
				pageable = pageable.previousOrFirst();
			}
		}
	
		return "Success";
	}
	
	//@Bean
	public String queries(){
		//1.
		System.out.println("Project name as Project1");
		empRepo.findByProject("Project1").forEach(System.out::println);
		//2.
		System.out.println("Project name as Project1 and name as Simran");
		empRepo.findByProjectAndName("Project1","Simran").forEach(System.out::println);
		//3.
		System.out.println("Name starting with S");
		empRepo.findByNameStartingWith("S").forEach(System.out::println);
		//4.
		System.out.println("Name containing lo");
		empRepo.findByNameContaining("lo").forEach(System.out::println);
		//5.
		System.out.println("Name ending with ni");
		empRepo.findByNameEndingWith("ni").forEach(System.out::println);
		//6.
		System.out.println("Salary between 100 and 250");
		empRepo.findBySalaryBetween(100, 250).forEach(System.out::println);
		//7.
		System.out.println("Name as Simran and project name as Project1");
		empRepo.findByNameOrProject("Simran","Project1").forEach(System.out::println);
		return "Success";
	}
	
	//@Bean
	public String customizedQuery(){
		empRepo.search("Project1", "Amar").forEach(System.out::println);
		return "Success";
	}
}
