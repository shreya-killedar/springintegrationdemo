package repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import model.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Integer>{

	//List of records with project as Project1
	public List<Employee> findByProject(String project);
	
	//List of records with project as Project1 and name as Simran
	public List<Employee> findByProjectAndName(String project, String name);
	
	//List of records with name starting with S
	public List<Employee> findByNameStartingWith(String startsWith);
	
	//List of records with name containing lo
	public List<Employee> findByNameContaining(String str);
	
	//List of records with name ending with ni
	public List<Employee> findByNameEndingWith(String endsWith);
	
	//List of records with salary between 100 and 250
	public List<Employee> findBySalaryBetween(double lowerLimit, double upperLimit);
	
	//List of records with name as Simran or project as Project1 
	public List<Employee> findByNameOrProject(String name, String project);
	
	//Customized query
	@Query(value="select e from Employee e where e.project=?1 and e.name = ?2")
	public List<Employee> search(String project, String name);
	
}
