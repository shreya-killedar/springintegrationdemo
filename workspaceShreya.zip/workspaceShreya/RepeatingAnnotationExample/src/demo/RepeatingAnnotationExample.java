package demo;

import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;


//Declaring repeatable annotation type
@Repeatable(Games.class)
@interface Game{
		String name();
		String day();
}
		

//Declaring container for repeatable annotation type
@Retention(RetentionPolicy.RUNTIME)
@interface Games{
		Game[] value();
}


//Repeating annotation
@Game(name = "Cricket", day="Sunday")
@Game(name = "Hockey", day="Monday")
@Game(name = "Football", day="Tuesday")
public class RepeatingAnnotationExample {
	
	public static void main(String[] args) {
		Game[] games = RepeatingAnnotationExample.class.getAnnotationsByType(Game.class);
		
		for (Game game : games) {
			System.out.println(game.name() +" on "+game.day());
		}
	}
}
