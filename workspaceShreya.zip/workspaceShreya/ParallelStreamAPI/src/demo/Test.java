package demo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Stream;

public class Test {

	public static void main(String[] args) {
		List<Integer> intList = new ArrayList<>();
		
		for(int i=0;i<100;i++){
			intList.add(i);
		}
		
		//sequential stream
		Stream<Integer> sequentialStream = intList.stream();
		//parallel stream
		//Stream<Integer> parallelStream = intList.stream().parallel();
		Stream<Integer> parallelStream = intList.parallelStream();
		
		
		long startTime = System.currentTimeMillis();
		//Filter parallel stream using StreamAPI where number > 90
		Stream<Integer> highNums = parallelStream.filter(n -> n>90);
		highNums.forEach(p -> System.out.println("High nums parallel : "+p+" : "+new Date()));
		long endTime = System.currentTimeMillis();
		System.out.println("Total time for parallel stream : "+(endTime-startTime));
		
		
		long startTimeSeq = System.currentTimeMillis();
		//Filter sequential stream using StreamAPI where number > 90
		Stream<Integer> highNumsSeq = sequentialStream.filter(n -> n>90);
		highNumsSeq.forEach(p -> System.out.println("High nums sequential : "+p+" : "+new Date()));
		long endTimeSeq = System.currentTimeMillis();
		System.out.println("Total time for sequential stream : "+(endTimeSeq-startTimeSeq));
	}

}
