package demo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Test {

	public static void main(String[] args) {
		List<Product> productList = new ArrayList<>();
		
		productList.add(new Product(1, "Samsung A5", 17000f));
		productList.add(new Product(3, "Iphone 6S", 65000f));
		productList.add(new Product(2, "Sony Xperia", 25000f));
		productList.add(new Product(4, "Nokia Lumia", 15000f));
		productList.add(new Product(5, "Redmi4", 26000f));
		productList.add(new Product(6, "Lenovo Vibe", 19000f));
		
		//Without filtering
		System.out.println("Without filtering");
		productList.forEach(p->System.out.println(p));
		
		//With filtering using logic
		System.out.println("With filtering using logic");
		for(Product p : productList){
			if(p.getPrice()>= 20000f){
				System.out.println(p);
			}
		}
		
		System.out.println("With filtering using predicate");
		productList.stream().filter(p->p.getPrice() > 20000).forEach(p->System.out.println(p));
	}
}
