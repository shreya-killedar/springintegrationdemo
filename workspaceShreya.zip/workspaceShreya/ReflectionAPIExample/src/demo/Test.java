package demo;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;

public class Test {
    public static void main(String[] args) throws NoSuchMethodException, SecurityException {
		Class<Bot> clazz = Bot.class;
		Constructor ctor = clazz.getConstructor(String.class, String.class, int.class, int.class);
	
		Parameter[] ctorParams = ctor.getParameters();
		System.out.println("Parameter reflection : ");
		for(Parameter param : ctorParams){
			System.out.println(param.isNamePresent()+" : "+param.getName());
		}
		
		Method[] methods = clazz.getMethods();
		System.out.println("Method reflection : ");
		for(Method met : methods){
			System.out.println(met.getName());
		}
	}
}
