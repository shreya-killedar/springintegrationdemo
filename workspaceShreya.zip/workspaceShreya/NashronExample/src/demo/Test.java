package demo;

import java.io.FileReader;

import javax.script.Invocable;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;

public class Test {
	public static void main(String[] args) throws Exception{
		//creating nashorn engine object
		ScriptEngine engine = new ScriptEngineManager().getEngineByName("nashorn");
		
		//Read the file and execute jjs command
		engine.eval(new FileReader("C:\\workspaceShreya\\sample.js"));
		
		//Convert engine into invocable
		Invocable invocable = (Invocable)engine;
		
		//invoke js function
		Object result = invocable.invokeFunction("fun1", "Peter Parker");
		System.out.println(result);
	}
}
