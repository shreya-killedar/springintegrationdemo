//print('Hello World!');

var fun1 = function(name){
	print('Hi there from Javascript, '+name);
	return "Greeting from Javascript";
}