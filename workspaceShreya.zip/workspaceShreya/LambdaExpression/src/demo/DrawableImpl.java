package demo;

public class DrawableImpl implements Drawable {

	@Override
	public void draw() {
		System.out.println("Drawing with DrawableImpl");
	}

}
