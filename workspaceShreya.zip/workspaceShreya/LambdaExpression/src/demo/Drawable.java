package demo;

@FunctionalInterface
public interface Drawable {
	void draw();
	
}
