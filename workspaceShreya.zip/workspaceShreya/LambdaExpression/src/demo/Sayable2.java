package demo;

@FunctionalInterface
public interface Sayable2 {
	public String say(String name);
}
