package demo;

@FunctionalInterface
public interface Addable {
	public int add(int a, int b);
}
