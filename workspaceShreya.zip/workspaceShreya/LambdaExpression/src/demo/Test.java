package demo;

public class Test {

	public static void main(String[] args) {
		
		//Using implementation class
		Drawable dr = new DrawableImpl();
		dr.draw();
		
		//Using anonymous inner class (Drawable implementation using anonymous class)
		Drawable andr = new Drawable() {
			
			@Override
			public void draw() {
				System.out.println("Drawing with Anonymous inner class");
			}
		};
		andr.draw();
		
		//Using lambda expression(anonymous function for providing method definition)
		
		//0 parameters
		Drawable ldr = ()->System.out.println("Drawing with Lambda expression"); //defining draw() method
		ldr.draw();//calling draw() method
		
		//1 parameter
		Sayable s = str->System.out.println("Sayable : Say "+str);
		s.say("Hii");
		
		//return value
		Sayable2 s2 = name -> name; //(name) -> {return name;};
		System.out.println("Sayable2 : Say Hii "+s2.say("Shreya"));
		
		//multiple statements, multiple parameters, return value
		Addable ad = (a,b)-> {
			System.out.println("Addable Add : ");
			return a+b; 
		}; //(a,b) -> a+b;
		System.out.println("a+b = "+ad.add(10, 20));
	}

}
