package demo;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import java.time.Period;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAdjusters;

public class Test {

	public static void main(String[] args) {
		//Current date
		LocalDate d = LocalDate.now();
		System.out.println("Current date : "+d);
		
		//Specific date
		LocalDate sd = LocalDate.of(2014, Month.JANUARY, 1);
		System.out.println("Specific date : "+sd);
		
		//Specific date - runtime error
		/*LocalDate sd1 = LocalDate.of(2014, Month.FEBRUARY, 29);
		System.out.println("Specific date : "+sd1);*/
		
		//Get available zones
		System.out.println(ZoneId.getAvailableZoneIds());
				
		//Current date in specific zone
		LocalDate zsd = LocalDate.now(ZoneId.of("Asia/Kolkata")); //America/Panama
		System.out.println("Current date in IST : "+zsd);
		
		//Getting base date from the base date i.e. 01/01/1970
		LocalDate ed = LocalDate.ofEpochDay(365);
		System.out.println("Date from base date : "+ed);
		
		//Getting 100th day of 2014
		LocalDate yd = LocalDate.ofYearDay(2014, 100);
		System.out.println("100th day of 2014 : "+yd);
				
		
		//Current time
		LocalTime t = LocalTime.now();
		System.out.println("Current time : "+t);
		
		//Specific time
		LocalTime st = LocalTime.of(12, 45, 52);
		System.out.println("Specific time : "+st);
		
		//Current date and time
		LocalDateTime dt = LocalDateTime.now();
		System.out.println("Current date and time : "+dt);
		
		//Specific date and time
		//LocalDateTime sdt = LocalDateTime.of(sd, st);
		LocalDateTime sdt = LocalDateTime.of(2014,Month.APRIL,4,13,25,18);
		System.out.println("Specific date and time : "+sdt);
		
		//TemporalAdjusters -> last day of year as of today's date
		LocalDate now = LocalDate.now();
		LocalDate adjustedDate = now.with(TemporalAdjusters.lastDayOfYear());
		System.out.println("now with last day of year : "+adjustedDate);
		
		//TemporalAdjusters -> last day of month as of today's date
		LocalDate now1 = LocalDate.now();
		LocalDate adjustedDate1 = now.with(TemporalAdjusters.lastDayOfMonth());
		System.out.println("now with last day of month : "+adjustedDate1);
		
		//Getting difference between months, dates
		LocalDate today = LocalDate.now();
		LocalDate lastDayOfYear = today.with(TemporalAdjusters.lastDayOfYear());
		Period period = today.until(lastDayOfYear);
		System.out.println("Period...Months remaining : "+period.getMonths());
		System.out.println("Period...Days remaining : "+period.getDays());
		
		//Number of days between today and last day of year
		System.out.println("Number of days between today and last day of year : "+ChronoUnit.DAYS.between(today, lastDayOfYear));
		
		//Difference between time --> last mid night
		Duration duration = Duration.between(LocalTime.MIDNIGHT, LocalTime.now());
		System.out.println("Difference between time : "+duration.toHours());
				
		//Format date                                                                                              
		System.out.println("Date in specific format : "+today.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))); //dd-MMM-yyyy
	}

}
