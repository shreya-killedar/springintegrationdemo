package demo;

@FunctionalInterface
public interface WorkerInterface {
	public void dosomething();
	//public void doSomeMoreTask(); //Compilation error  
}
