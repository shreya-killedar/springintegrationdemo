package demo;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

public class FutureTest {

	public static void main(String[] args) throws InterruptedException, ExecutionException {
		Callable<Integer> service1 = () -> {
		    try {
		    	for(int i=0;i<100;i++)
		    	{
		    		System.out.println(i);
		    	}
		    	System.out.println(Thread.currentThread().getName()+" is doing long running task");
		        TimeUnit.SECONDS.sleep(10);
		        System.out.println("Long running Task over");
				 return 123;
		    }
		    catch (InterruptedException e) {
		        throw new IllegalStateException("task interrupted", e);
		    }
		};
		
		ExecutorService executor = Executors.newFixedThreadPool(1);
		Future<Integer> future = executor.submit(service1);
		
		System.out.println(Thread.currentThread().getName()+" is waiting till get result from another service");
		TimeUnit.SECONDS.sleep(5);
	    Integer result = future.get();
		
		System.out.println(" Got result: from sevice " + result);
		System.out.println("Then only main will do further processing");
	}

}
