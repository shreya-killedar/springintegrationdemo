package demo;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class CompletableFutureTest {
	public static void main(String[] args) throws InterruptedException, ExecutionException {
		ExecutorService executor = Executors.newFixedThreadPool(1);
		CompletableFuture cf = CompletableFuture.supplyAsync( ( ) -> {
			
			try {
		    	for(int i=0;i<100;i++)
		    	{
		    		System.out.println(i);
		    	}
		        
		        System.out.println(Thread.currentThread().getName()+"is doing long running task");
		        TimeUnit.SECONDS.sleep(10);
		        System.out.println("Long running Task over");
		        return 123;
		    }
		    catch (InterruptedException e) {
		        throw new IllegalStateException("task interrupted", e);
		    }
		},executor);
		
		System.out.println("Main is waiting till get result from another service");
		
		TimeUnit.SECONDS.sleep(5);
      
		cf.complete(" explicitly Done!");
		Object result = cf.get();
		
		System.out.println(" Got result: from sevice " + result);
		System.out.println("Then only main will do further processing");
		
	}


}
