package streamassignment;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Test {

	public static void main(String[] args) {

		List<Employee> employees = Arrays.asList(
				new Employee(1276,"AAA",2000.00),
				new Employee(7895,"BBB",3000.00),
				new Employee(7843,"CCC",12000.00),
				new Employee(1235,"DDD",22000.00),
				new Employee(4512,"EEE",24000.00),
				new Employee(6369,"FFF",1000.00),
				new Employee(4147,"GGG",200.00),
				new Employee(8525,"HHH",3000.00),
				new Employee(7842,"III",4000.00),
				new Employee(6581,"JJJ",6000.00),
				new Employee(4444,"KKK",7000.00));
		
	    long startTimeSeq = System.currentTimeMillis();
		List<Employee> salariesSeq = employees.stream().filter(e -> e.getSalary()>2000).collect(Collectors.toList());
		long endTimeSeq = System.currentTimeMillis();
		System.out.println("Time for sequential : "+(endTimeSeq-startTimeSeq));
		
		long startTimePar = System.currentTimeMillis();
		List<Employee> salariesPar = employees.parallelStream().filter(e -> e.getSalary()>2000).collect(Collectors.toList());
		long endTimePar = System.currentTimeMillis();
		System.out.println("Time for parallel : "+(endTimePar-startTimePar));
	}

}
