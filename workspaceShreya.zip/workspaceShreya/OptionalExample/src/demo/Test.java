package demo;

import java.util.Optional;

public class Test {
	public static void main(String[] args) {
		Integer value1 = null;
		Integer value2 = new Integer(10);
		
		Optional<Integer> a = Optional.ofNullable(value1);
		System.out.println(a.toString() +" : "+ a);
		
		Optional<Integer> b = Optional.of(value2);
		System.out.println(b);
	}
}
