package demo;

public interface ClosableDefault {
	void close(String str);
	
	default public void log(String str){
		System.out.println("ClosableDefault logging: "+str);
	}
}
