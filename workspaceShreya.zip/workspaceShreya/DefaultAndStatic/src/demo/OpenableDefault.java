package demo;

public interface OpenableDefault {
	void open(String str);
	
	default public void log(String str){
		System.out.println("OpenableDefault logging: "+str);
	}
	
	
}
