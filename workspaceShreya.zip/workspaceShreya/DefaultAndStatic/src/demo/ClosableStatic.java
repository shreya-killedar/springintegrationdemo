package demo;

public interface ClosableStatic {
	void close(String str);
	
	public static void print(){
		System.out.println("ClosableStatic logging");
	}
	
	
}
