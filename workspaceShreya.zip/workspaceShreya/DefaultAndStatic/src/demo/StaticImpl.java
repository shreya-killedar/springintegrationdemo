package demo;

public class StaticImpl implements OpenableStatic, ClosableStatic{

	@Override
	public void open(String str) {
		System.out.println("StaticImpl open: "+str);
	}


	@Override
	public void close(String str) {
		System.out.println("StaticImpl close: "+str);
	}
	
}
