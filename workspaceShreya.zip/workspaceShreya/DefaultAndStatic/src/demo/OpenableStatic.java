package demo;

public interface OpenableStatic {
	void open(String str);
	
	public static void print(){
		System.out.println("OpenableStatic logging");
	}
	
	
}
