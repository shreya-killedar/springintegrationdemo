package demo;

public class Test {

	public static void main(String[] args) {
		DefaultImpl odi = new DefaultImpl();
		odi.open("Hi");
		odi.close("Hello");
		odi.log("Log calling...");
		
		StaticImpl sdi = new StaticImpl();
		sdi.open("Hi");
		sdi.close("Hello");
		OpenableStatic.print();
		ClosableStatic.print();
	}

}
