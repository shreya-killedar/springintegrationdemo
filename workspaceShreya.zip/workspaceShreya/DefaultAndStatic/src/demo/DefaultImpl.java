package demo;

public class DefaultImpl implements OpenableDefault, ClosableDefault{

	@Override
	public void open(String str) {
		System.out.println("DefaultImpl open: "+str);
	}


	@Override
	public void close(String str) {
		System.out.println("DefaultImpl close: "+str);
	}
	
    public void log(String str){
	   	OpenableDefault.super.log("log1");
	   	ClosableDefault.super.log("log2");
	}
}
