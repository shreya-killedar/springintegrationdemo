package demo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Test {

	public static void main(String[] args) {
		List<Product> productList = new ArrayList<>();
		
		productList.add(new Product(1, "HP Laptop", 25000f));
		productList.add(new Product(3, "Keyboard", 300f));
		productList.add(new Product(2, "Dell Mouse", 150f));
		
		//Without sorting
		System.out.println("Without sorting");
		productList.forEach(p->System.out.println(p));
		
		System.out.println("Sorted using Comparator implementation class");
		//Collections.sort(productList, new NameComparator());
		productList.sort(new NameComparator());
		productList.forEach(p->System.out.println(p));
		
		System.out.println("Sorted using lambda expression for Comparator");
		/* productList.sort((p1,p2)->p1.getName().compareTo(p2.getName()));
		productList.forEach(p->System.out.println(p)); */
		productList.stream().sorted((p1,p2)->p1.getName().compareTo(p2.getName())).forEach(p->System.out.println(p));
	}

}
