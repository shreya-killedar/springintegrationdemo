package demo;

import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class BookSearch {
	public List<Book> serachByAuthor(List<Book> bookList, String author){
		List<Book> filteredList = bookList.parallelStream()
				.filter(b -> b.getAuthor().equalsIgnoreCase(author))
				.collect(Collectors.toList());
		return filteredList;
	}
	
	public List<Book> serachByPrice(List<Book> bookList, int price){
		List<Book> filteredList = bookList.parallelStream()
				.filter(b -> b.getPrice()==price)
				.collect(Collectors.toList());
		return filteredList;
	}
	
	/*public List<Book> serachByField(List<Book> bookList, String filterBy, Object value){
		List<Book> filteredList = bookList.parallelStream()
				.filter(b -> {
					switch(filterBy){
						case "Book Id":
							return value.equals(b.getBookId());
						case "Book Name":
							return value.equals(b.getBookName());
						case "Author":
							return value.equals(b.getAuthor());
						case "Price":
							return value.equals(b.getPrice());
						case "Page Count":
							return value.equals(b.getPageCount());
						default :
							return false;
					}
				})
				.collect(Collectors.toList());
		return filteredList;
	}*/
	
	public List<Book> serachByField(List<Book> bookList, Predicate<Book> pred){
		List<Book> filteredList = bookList.parallelStream()
				.filter(pred)
				.collect(Collectors.toList());
		return filteredList;
	}
}
