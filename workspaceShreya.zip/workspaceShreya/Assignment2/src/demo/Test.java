package demo;

import java.util.ArrayList;
import java.util.List;

public class Test {

	public static void main(String[] args) {
		List<Book> bookList = new ArrayList<>();
		bookList.add(new Book(101,"Thinking in Java","Ramesh Sharma",550,450));
		bookList.add(new Book(102,"Head First Java","Kamal Kumar",350,450));
		bookList.add(new Book(103,"Learn Java in 21 days","Suresh Agrawal",450,850));
		bookList.add(new Book(104,"Learning Java Yourself","Kamal Kumar",750,650));
		bookList.add(new Book(105,"Java in action","Tanya Arora",450,750));
		bookList.add(new Book(106,"Mastering in Java","Paarth Chaudhary",650,350));
		bookList.add(new Book(107,"Java Black Book","Sumit Kapoor",850,450));
		
		BookSearch bs = new BookSearch();
		System.out.println("Search by author : ");
		List<Book> booksByAuthor = bs.serachByAuthor(bookList, "Kamal Kumar");
		booksByAuthor.forEach(System.out::println);
		
		System.out.println("Search by price : ");
		List<Book> booksByPrice = bs.serachByPrice(bookList, 450);
		booksByPrice.forEach(System.out::println);
		
		System.out.println("Search by field : ");
		/*System.out.println("By Book Id : ");
		List<Book> bbiList = bs.serachByField(bookList, "Book Id", 105);
		bbiList.forEach(System.out::println);
		
		System.out.println("By Book Name : ");
		List<Book> bbnList = bs.serachByField(bookList, "Book Name", "Learn Java in 21 days");
		bbnList.forEach(System.out::println);
		
		System.out.println("By Author : ");
		List<Book> baList = bs.serachByField(bookList, "Author", "Sumit Kapoor");
		baList.forEach(System.out::println);
		
		System.out.println("By Price : ");
		List<Book> bpList = bs.serachByField(bookList, "Price", 650);
		bpList.forEach(System.out::println);
		
		System.out.println("By Page Count : ");
		List<Book> bpcList = bs.serachByField(bookList, "Page Count", 450);
		bpcList.forEach(System.out::println);*/
		
		System.out.println("By Book Id : ");
		List<Book> bbiList = bs.serachByField(bookList, b->b.getBookId()==101);
		bbiList.forEach(System.out::println);
		
		System.out.println("By Book Name : ");
		List<Book> bbnList = bs.serachByField(bookList, b->b.getBookName().equalsIgnoreCase("Learn Java in 21 days"));
		bbnList.forEach(System.out::println);
		
		System.out.println("By Author : ");
		List<Book> baList = bs.serachByField(bookList, b->b.getAuthor().equalsIgnoreCase("Sumit Kapoor"));
		baList.forEach(System.out::println);
		
		System.out.println("By Price : ");
		List<Book> bpList = bs.serachByField(bookList, b->b.getPrice()>200);
		bpList.forEach(System.out::println);
		
		System.out.println("By Page Count : ");
		List<Book> bpcList = bs.serachByField(bookList, b->b.getPageCount()>=450);
		bpcList.forEach(System.out::println);
	}
	
	

}
