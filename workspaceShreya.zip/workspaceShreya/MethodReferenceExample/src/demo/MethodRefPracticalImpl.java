package demo;

import java.util.ArrayList;
import java.util.List;

public class MethodRefPracticalImpl {
	public static void main(String[] args) {
		 List<String> list = new ArrayList<>();
    	 list.add("Aarti");
    	 list.add("Priya");
    	 list.add("Isha");
    	 list.add("Jany");
    	     	 
    	 //Using lambda expression with forEach
    	 System.out.println("Using lambda expression with forEach"); 
    	 list.forEach(n->System.out.println(n));
    	 
    	 //Using method reference with forEach
    	 System.out.println("Using method reference with forEach"); 
    	 list.forEach(System.out::println);
	}
}
