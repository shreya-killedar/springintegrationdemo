package demo;

public class MethodRef {
	
	public MethodRef(){}
	
	public MethodRef(int s){
		System.out.println("Inside MethodRef constructor : "+s);
	}
	
	public static void sayStaticMethod(int s){
		System.out.println("Inside sayStaticMethod method : "+s);
	}
	
	public void sayInstanceMethod(int s){
		System.out.println("Inside sayInstanceMethod method : "+s);
	}
}
