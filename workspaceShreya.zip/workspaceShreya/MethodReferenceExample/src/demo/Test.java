package demo;

public class Test {

	public static void main(String[] args) {
		
		//Using lambda for static method
		Sayable s1 = a -> MethodRef.sayStaticMethod(a);
		s1.say(10);

		//Using method reference for static method
		Sayable s2 = MethodRef::sayStaticMethod;
		s2.say(20);
		
		//Using lambda for instance method
		Sayable s3 = a -> new MethodRef().sayInstanceMethod(a);
		s3.say(30);
		
		//Using method reference for instance method
		//Sayable s4 = new MethodRef(12)::sayInstanceMethod; --> if we don't write 0 parameter constructor
		Sayable s4 = new MethodRef()::sayInstanceMethod;
		s4.say(40);
		
		//Using lambda for constructor
		Sayable s5 = a -> new MethodRef(a);
		s5.say(50);
				
		//Using method reference for constructor 
		Sayable s6 =  MethodRef::new;
		s6.say(60);
		
	}

}
