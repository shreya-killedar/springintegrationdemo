package demo;

@FunctionalInterface
public interface Sayable {
	public void say(int s);
}
