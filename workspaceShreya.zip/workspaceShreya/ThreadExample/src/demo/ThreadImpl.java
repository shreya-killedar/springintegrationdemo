package demo;

public class ThreadImpl implements Runnable {

	@Override
	public void run() {
		System.out.println("Inside ThreadImpl");
	}

}
