package demo;

public class Test {

	public static void main(String[] args) {
		
		//Using implementation class
		Runnable r = new ThreadImpl();
		Thread t = new Thread(r);
		t.start();
		
		//Using lambda expression
		
		/*Runnable rl = () -> System.out.println("run() implementation using lambda expression");
		Thread t1 = new Thread(rl);*/
		
		/*Thread t1 = new Thread(()->System.out.println("run() implementation using lambda expression"));
		t1.start();*/
		
		new Thread(()->System.out.println("run() implementation using lambda expression")).start();
	}

}
