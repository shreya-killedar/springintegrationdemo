package demo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Test {

	public static void main(String[] args) {
		ArrayList<Float> arr = new ArrayList<>();
		arr.add(10.00f);
		arr.add(3.00f);
		arr.add(5.00f);
		arr.add(12.00f);
		arr.add(19.00f);
		
		//forEach(Consumer)
		System.out.println("forEach() : ");
		arr.forEach(System.out::println);
		
		//removeIf(Predicate)
		arr.removeIf(s -> s>15);
		System.out.println("removeIf() : ");
		arr.forEach(System.out::println);
		
		//sort(Comparator)
		arr.sort((a,b)-> a.compareTo(b));
		System.out.println("sort() : ");
		arr.forEach(System.out::println);
		
		//forEach(BiConsumer)
		Map<String, Integer> m = new HashMap<>();
		m.put("Robert Ludlum",27);
		m.put("Clive Cussler",50);
		m.put("Tom Clancy",17);
		m.forEach((k,v) -> System.out.println("Key : "+k+", Value : "+v));
		
		//compute(key, BiFunction)
		System.out.println("compute() : ");
		m.compute("Clive Cussler", (a,b) -> b+1);
		m.forEach((k,v) -> System.out.println("Key : "+k+", Value : "+v));
	}

}
