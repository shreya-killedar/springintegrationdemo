package demo;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Test {
	public static void main(String[] args) {
		List<Product> productList = new ArrayList<>();
		
		productList.add(new Product(1, "Samsung A5", 25000f));
		productList.add(new Product(3, "iPhone 6S", 65000f));
		productList.add(new Product(2, "Sony Xperia", 25000f));
		productList.add(new Product(4, "Nokia Lumia", 15000f));
		productList.add(new Product(5, "Redmi4", 26000f));
		productList.add(new Product(6, "Lenovo Vibe", 19000f));
		
		productList.forEach(System.out::println);
		
		//Filter the list and collect filtered data in another list using traditional way
		/*System.out.println("Filtered list using traditional way : Price<30000");
		List<Product> lowPriceProducts =  new ArrayList<>();
		for(Product p : productList){
			if(p.getPrice()<30000){
				lowPriceProducts.add(p);
			}
		}
		lowPriceProducts.forEach(System.out::println);*/
	
		//Filter the list and collect filtered data in another list using StreamAPI
		System.out.println("Filtered list using StreamAPI : Price<30000");
		List<Product> lowPriceProductsStream =  productList.stream().filter(p->p.price<30000).collect(Collectors.toList());
		lowPriceProductsStream.forEach(System.out::println);
		
		
		//Fetch list of price --> Traditional way
		/*System.out.println("List of Price : Traditional way ");
		List<Float> priceList = new ArrayList<>();
		for(Product p : lowPriceProductsStream){
			priceList.add(p.price);
		}
		priceList.forEach(System.out::println);*/
		
		//Fetch list of price --> Using StreamAPI
		System.out.println("List of Price : Using StreamAPI ");
		List<Float> priceListStream = productList.stream().filter(p->p.price<30000)
				.map(a -> a.price)
				.collect(Collectors.toList()); 
		priceListStream.forEach(System.out::println);
		
		//Fetch list of distinct price --> Using StreamAPI
		System.out.println("List of distinct price : Using StreamAPI ");
		List<Float> distinctPriceListStream = productList.stream().filter(p->p.price<30000)
				.map(a -> a.price)
				.distinct()
				.collect(Collectors.toList()); 
		distinctPriceListStream.forEach(System.out::println);
		
		//Fetch list of distinct price --> Using StreamAPI
		System.out.println("Soted list of distinct price : Using StreamAPI ");
		List<Float> distinctPriceListStreamSorted = productList.stream().filter(p->p.price<30000)
		    	.map(a -> a.price)
				.distinct()
				.sorted() //use sorted(Comparator) method to customize sorting
				.collect(Collectors.toList()); 
		distinctPriceListStreamSorted.forEach(System.out::println);
		
		//Fetch list of first 2 prices --> Using StreamAPI
		System.out.println("List of first 2 prices : Using StreamAPI ");
		List<Float> firstTwoPriceListStream = productList.stream().filter(p->p.price<30000)
		    	.map(a -> a.price)
		    	.limit(2)
				.collect(Collectors.toList()); 
		firstTwoPriceListStream.forEach(System.out::println);
		
		//Skip first element --> Using StreamAPI
		System.out.println("Skip first element : Using StreamAPI ");
		List<Float> skipFirstElementPriceListStream = productList.stream().filter(p->p.price<30000)
		    	.map(a -> a.price)
		    	.skip(1)
				.collect(Collectors.toList()); 
		skipFirstElementPriceListStream.forEach(System.out::println);
		
		//Sum of price --> Using StreamAPI
		System.out.println("Sum of price : Using StreamAPI ");
		Float totalPrice = productList.stream().filter(p->p.price<30000)
		    	.map(a -> a.price)
		    	.reduce(0.0f,(sum,price)->sum + price);
		
		//Another way 
		/*Double totalPrice = productList.stream().filter(p->p.price<30000)
		    	.mapToDouble(a -> a.price)
		    	.sum();*/
		
		System.out.println("Total Price : "+totalPrice);
    }
}