package demo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class Test {
     public static void main(String[] args) {
    	 List<String> list = new ArrayList<>();
    	 list.add("Aarti");
    	 list.add("Priya");
    	 list.add("Isha");
    	 list.add("Jany");
    	 
    	 //Iterating over list using enhanced for loop
    	 System.out.println("Using enhanced for loop");
    	 for (String name : list) {
			System.out.println(name);
    	 }
    	 
    	 //Using forEach method
    	 System.out.println("Using forEach method"); 
    	 list.forEach(n->System.out.println(n));
    	 
    	 Map<Integer, String> m = new HashMap<>();
    	 m.put(1, "Ankit");
    	 m.put(2, "Mayank");
    	 m.put(3, "Irfan");
    	 m.put(4, "Jai");
    	 
    	 //Iterating over list using enhanced for loop
    	 System.out.println("Using enhanced for loop");
    	 for (Entry<Integer, String> e : m.entrySet()) {
			System.out.println("Key : "+e.getKey()+" Value : "+e.getValue());
		 }
    	 
    	//Using forEach method
    	 System.out.println("Using forEach method"); 
    	 m.forEach((k,v)->System.out.println("Key : "+k+" Value : "+v)); 
	 }
}
