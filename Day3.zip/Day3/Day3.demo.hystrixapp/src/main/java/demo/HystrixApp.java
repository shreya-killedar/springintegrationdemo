package demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.netflix.hystrix.EnableHystrix;
import org.springframework.cloud.netflix.hystrix.dashboard.EnableHystrixDashboard;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@SpringBootApplication
@RestController
@EnableCircuitBreaker // show circuits
@EnableHystrix //+actuator ->  http://localhost:8081/actuator/hystrix.stream
@EnableHystrixDashboard //-> http://localhost:8081/hystrix
public class HystrixApp {

	public static void main(String[] args) {
		SpringApplication.run(HystrixApp.class, args);
	}
	
	@GetMapping(value="/")
	@HystrixCommand(commandKey="demo1", groupKey="db", fallbackMethod="method1")
	public Object[] get(){
		System.out.println("inside get method........");
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<Object[]> re = restTemplate.getForEntity("http://localhost:9090/depts", Object[].class);
		return re.getBody();
	}
	
	@GetMapping(value="/abc")
	@HystrixCommand(commandKey="demo2", groupKey="db1", fallbackMethod="method1")
	public Object[] get1(){
		System.out.println("inside get1 method........");
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<Object[]> re = restTemplate.getForEntity("http://localhost:9090/depts", Object[].class);
		return re.getBody();
	}
	
	public Object[] method1(){
		System.out.println("inside fallback method........");
		String[] arr = new String[]{"static data","simple data"};
		return arr;
	}

}
