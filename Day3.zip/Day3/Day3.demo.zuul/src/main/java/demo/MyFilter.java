package demo;

import java.util.Date;

import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.exception.ZuulException;

public class MyFilter extends ZuulFilter {

  @Override
  public String filterType() {
	  System.out.println("filterType invoked ");
	  return "pre";
  }

  @Override
  public int filterOrder() {
	  System.out.println("filterOrder invoked ");
	  return 0;
  }

  @Override
  public boolean shouldFilter() {
	  System.out.println("shouldFilter invoked ");
	  return true;
  }

  @Override
  public Object run() throws ZuulException {
	System.out.println("run invoked "+new Date());
    return null;
  }

}