package demo;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import model.Dept;
import repo.DeptRepository;

@SpringBootApplication
@EnableJpaRepositories(basePackages="repo")
@EntityScan(basePackages="model")
@RestController
public class DBApplication {
	
	@Autowired
	DeptRepository repo;
	

	public static void main(String[] args) {
		SpringApplication.run(DBApplication.class, args);
	}
	
	@GetMapping(value="/depts", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Dept> findAll(){
		if(new Date().getTime()%2 == 0){
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {
			throw new RuntimeException("Error");
		}
		return repo.findAll();
	}
	
	@GetMapping(value="/")
	public String index(){
		System.out.println("in index of db app"+new Date());
		return "<h1><a href='depts'>List of Departments</a></h1>"; 
	}

}
