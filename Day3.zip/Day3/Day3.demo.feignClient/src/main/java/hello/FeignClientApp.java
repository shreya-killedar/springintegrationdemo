package hello;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import demo.Dept;
import demo.DeptClient;
import demo.ReqResClient;
import demo.User;
import demo.Wrapper;
import feign.RequestInterceptor;
import feign.RequestTemplate;

@EnableFeignClients(basePackages="demo")
@SpringBootApplication(scanBasePackages="demo")
@RestController
@RequestMapping(value="/")
public class FeignClientApp {
	
	@Autowired
	private DeptClient deptClient;

	@Autowired
	private ReqResClient reqClient;
	
	public static void main(String[] args) {
		SpringApplication.run(FeignClientApp.class, args);
	}
	
	@GetMapping
	public String list(){	
		//go to db service, get all departments and show
		List<Dept> depts = deptClient.findAll();
		return "<h1>List size : "+depts.size()+"</h1>";
	}
	
	@Bean
	public RequestInterceptor requestInt(){
		return new RequestInterceptor() {
			
			@Override
			public void apply(RequestTemplate reqTemplate) {
				// TODO Auto-generated method stub
				reqTemplate.header("user-agent", "Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36");
			}
		};
		
	}
	
	@GetMapping(value="req")
	public String listReq(){	
		Wrapper pageDetails = reqClient.getData();
		String str="<h1>Page="+pageDetails.getPage()+"</h1>";
		str+=pageDetails.toString();
		str+="<table>";
		List<User> users = pageDetails.getData();
		for(int i=0;i<users.size();i++){
			str+="<tr><td>"+users.get(i).getId()+"</td><td>"
					+users.get(i).getFirst_name()+"</td><td>"
					+users.get(i).getLast_name()+"</td><td>"
					+"<img src= '"+users.get(i).getAvatar()+"'></td></tr>";
		}
		str+="</table>";
		System.out.println(str);
		return str;
	}

}
