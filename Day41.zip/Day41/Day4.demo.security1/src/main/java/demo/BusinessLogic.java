package demo;

import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Component;

@Component
public class BusinessLogic {
	@Secured(value="ROLE_std")
	public void m1(){
		System.out.println("Invoked m1");
	}
	@Secured(value="ROLE_adm")
	public void m2(){
		System.out.println("Invoked m2");
	}
	
	public void m0() {
		System.out.println("Invoked m0");
	}
}
